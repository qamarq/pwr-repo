let sumak (a,b,c,d) = a +. b +. c +. d;;

sumak (3.,2.,5.,1.);;
sumak (0.,1.,-1.,1.);;
sumak (0.,0.,0.,0.);;