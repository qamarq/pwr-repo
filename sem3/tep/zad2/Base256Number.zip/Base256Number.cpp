#include "Base256Number.h"

#include <iomanip>
#include <iostream>
#include <sstream>

Base256Number::Base256Number() {
    i_numbers = new unsigned char[1];
    i_numbers[0] = 0;
    i_size = 1;
}

Base256Number::Base256Number(const Base256Number &pcOther) {
    i_size = pcOther.i_size;
    i_numbers = new unsigned char[i_size];
    for (int i = 0; i < i_size; i++) i_numbers[i] = pcOther.i_numbers[i];
}

Base256Number::~Base256Number() {
    delete[] i_numbers;
}

Base256Number& Base256Number::operator=(const Base256Number &pcOther) {
    if (this != &pcOther) {
        delete[] i_numbers;
        i_size = pcOther.i_size;
        i_numbers = new unsigned char[i_size];
        for (int i = 0; i < i_size; i++) i_numbers[i] = pcOther.i_numbers[i];
    }
    return *this;
}

Base256Number& Base256Number::operator=(const int iValue) {
    int iTmp = iValue;
    int iBytes = 0;
    int iCopy = iTmp;
    while (iCopy > 0) {
        iBytes++;
        iCopy /= 256;
    }
    if (iBytes == 0) iBytes = 1;

    delete[] i_numbers;
    i_size = iBytes;
    i_numbers = new unsigned char[i_size];

    for (int i = i_size - 1; i >= 0; i--) {
        std::cout << iTmp << iTmp % 256 << std::endl;
        i_numbers[i] = iTmp % 256;
        iTmp /= 256;
    }

    // debug number
    // for (int i = 0; i < (i_size - 1); i++) {
    //     std::cout << int(i_numbers[i]) << " ";
    // };

    return *this;
}

std::string Base256Number::toHexString() const {
    std::ostringstream cStream;
    cStream << "0x";
    for (int i = 0; i < i_size; i++)
        cStream << std::hex << std::setw(2) << std::setfill('0') << (int)i_numbers[i];
    return cStream.str();
}

int Base256Number::toInt() const {
    int out = 0;

    for (int i = 0; i < i_size - 1; i++) {
        out += i_numbers[i] * 256;
    }

    out += i_numbers[i_size];
    return out;
}

Base256Number Base256Number::operator&(const Base256Number &pcOther) const {
    int iMaxSize = std::max(i_size, pcOther.i_size);
    Base256Number cResult;
    delete[] cResult.i_numbers;
    cResult.i_numbers = new unsigned char[iMaxSize];
    cResult.i_size = iMaxSize;
    for (int i = 0; i < iMaxSize; i++) {
        int iA = (i >= i_size) ? 0 : i_numbers[i_size - 1 - i];
        int iB = (i >= pcOther.i_size) ? 0 : pcOther.i_numbers[pcOther.i_size - 1 - i];
        cResult.i_numbers[iMaxSize - 1 - i] = (unsigned char)(iA & iB);
    }
    return cResult;
}

Base256Number Base256Number::operator|(const Base256Number &pcOther) const {
    int iMaxSize = std::max(i_size, pcOther.i_size);
    Base256Number cResult;
    delete[] cResult.i_numbers;
    cResult.i_numbers = new unsigned char[iMaxSize];
    cResult.i_size = iMaxSize;
    for (int i = 0; i < iMaxSize; i++) {
        int iA = (i >= i_size) ? 0 : i_numbers[i_size - 1 - i];
        int iB = (i >= pcOther.i_size) ? 0 : pcOther.i_numbers[pcOther.i_size - 1 - i];
        cResult.i_numbers[iMaxSize - 1 - i] = (unsigned char)(iA | iB);
    }
    return cResult;
}

Base256Number Base256Number::operator^(const Base256Number &pcOther) const {
    int iMaxSize = std::max(i_size, pcOther.i_size);
    Base256Number cResult;
    delete[] cResult.i_numbers;
    cResult.i_numbers = new unsigned char[iMaxSize];
    cResult.i_size = iMaxSize;
    for (int i = 0; i < iMaxSize; i++) {
        int iA = (i >= i_size) ? 0 : i_numbers[i_size - 1 - i];
        int iB = (i >= pcOther.i_size) ? 0 : pcOther.i_numbers[pcOther.i_size - 1 - i];
        cResult.i_numbers[iMaxSize - 1 - i] = (unsigned char)(iA ^ iB);
    }
    return cResult;
}

Base256Number Base256Number::operator~() const {
    Base256Number cResult;
    delete[] cResult.i_numbers;
    cResult.i_numbers = new unsigned char[i_size];
    cResult.i_size = i_size;
    bool bLeading = true;
    for (int i = 0; i < i_size; i++) {
        if (bLeading && i_numbers[i] == 0 && i < i_size - 1) {
            cResult.i_numbers[i] = 0;
        } else {
            bLeading = false;
            cResult.i_numbers[i] = (unsigned char)(~i_numbers[i]);
        }
    }
    return cResult;
}

Base256Number Base256Number::operator<<(int iShift) const {
    int iByteShift = iShift / 8;
    int iBitShift = iShift % 8;
    Base256Number cResult;
    delete[] cResult.i_numbers;
    cResult.i_size = i_size + iByteShift + 1;
    cResult.i_numbers = new unsigned char[cResult.i_size];
    for (int i = 0; i < cResult.i_size; i++) cResult.i_numbers[i] = 0;

    for (int i = 0; i < i_size; i++) {
        int iPos = i + iByteShift;
        unsigned short iVal = (unsigned short)i_numbers[i] << iBitShift;
        cResult.i_numbers[iPos] |= (unsigned char)(iVal & 0xFF);
        if (iPos > 0) cResult.i_numbers[iPos - 1] |= (unsigned char)((iVal >> 8) & 0xFF);
    }
    return cResult;
}

Base256Number Base256Number::operator>>(int iShift) const {
    int iByteShift = iShift / 8;
    int iBitShift = iShift % 8;
    if (iByteShift >= i_size) {
        Base256Number cZero;
        cZero = 0;
        return cZero;
    }
    int iNewSize = i_size - iByteShift;
    Base256Number cResult;
    delete[] cResult.i_numbers;
    cResult.i_numbers = new unsigned char[iNewSize];
    cResult.i_size = iNewSize;
    for (int i = 0; i < iNewSize; i++) cResult.i_numbers[i] = 0;

    for (int i = i_size - 1; i >= iByteShift; i--) {
        int iPos = i - iByteShift;
        unsigned short iVal = (unsigned short)i_numbers[i] >> iBitShift;
        cResult.i_numbers[iPos] |= (unsigned char)(iVal & 0xFF);
        if (iPos < iNewSize - 1)
            cResult.i_numbers[iPos + 1] |= (unsigned char)((i_numbers[i] << (8 - iBitShift)) & 0xFF);
    }
    return cResult;
}