#ifndef ZAD2_BASE256NUMBER_H
#define ZAD2_BASE256NUMBER_H

#include <string>

class Base256Number {
private:
    unsigned char* i_numbers;
    int i_size;

public:
    Base256Number();
    Base256Number(const Base256Number &pcOther);
    ~Base256Number();

    Base256Number& operator=(const Base256Number &pcOther);
    Base256Number& operator=(const int iValue);

    std::string toHexString() const;
    int toInt() const;

    Base256Number operator&(const Base256Number &pcOther) const;
    Base256Number operator|(const Base256Number &pcOther) const;
    Base256Number operator^(const Base256Number &pcOther) const;
    Base256Number operator~() const;
    Base256Number operator<<(int iShift) const;
    Base256Number operator>>(int iShift) const;
};

#endif