#ifndef ALLOC_FUNCS_H
#define ALLOC_FUNCS_H
#include "constants.h"
#include <iostream>


void v_alloc_table_fill_34(int size);
bool b_alloc_table_2_dim(int ***tab, int cols, int rows);
bool b_dealloc_table_2_dim(int ***tab, int cols);


#endif