#ifndef CONSTANTS_H
#define CONSTANTS_H
#include <string>
static const std::string DEFAULT_NAME = "CTable_default";
static const int DEFAULT_TABLE_LEN = 5;
static const int FILL_VALUE_34 = 34;
static const int DEFAULT_TABLE_COLS = 5;
static const int DEFAULT_TABLE_ROWS = 3;
#endif